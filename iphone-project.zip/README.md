# Projeto iPhone (Simulação de Funcionalidades)

Este projeto simula as funcionalidades básicas de um iPhone de 2007, com três componentes principais:

- **Reprodutor Musical**: Para tocar, pausar e selecionar músicas.
- **Aparelho Telefônico**: Para realizar chamadas, atender e acessar o correio de voz.
- **Navegador Internet**: Para exibir páginas, adicionar novas abas e atualizar páginas.

## Estrutura do Projeto

O projeto é organizado da seguinte forma:

- `ReprodutorMusical.java`: Implementa o reprodutor musical com métodos para tocar, pausar e selecionar músicas.
- `AparelhoTelefonico.java`: Implementa o aparelho telefônico com métodos para ligar, atender e acessar o correio de voz.
- `NavegadorInternet.java`: Implementa o navegador da internet com métodos para exibir páginas, adicionar novas abas e atualizar páginas.
- `iPhone.java`: Classe principal que agrupa as funcionalidades do iPhone.
- `Main.java`: Classe com o exemplo de uso das funcionalidades do iPhone.

## Como Usar

1. Compile os arquivos Java:
    ```bash
    javac *.java
    ```

2. Execute o programa:
    ```bash
    java Main
    ```

## Licença

Este projeto é de código aberto e distribuído sob a licença MIT.
