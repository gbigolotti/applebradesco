public class Main {
    public static void main(String[] args) {
        iPhone meuIphone = new iPhone();

        // Usando o Reprodutor Musical
        meuIphone.selecionarMusica("Shape of You");
        meuIphone.tocarMusica();
        meuIphone.pausarMusica();

        // Usando o Aparelho Telefônico
        meuIphone.ligarPara("123456789");
        meuIphone.atenderChamada();
        meuIphone.iniciarCorreioVoz();

        // Usando o Navegador de Internet
        meuIphone.exibirPagina("www.google.com");
        meuIphone.adicionarNovaAba();
        meuIphone.atualizarPagina();
    }
}